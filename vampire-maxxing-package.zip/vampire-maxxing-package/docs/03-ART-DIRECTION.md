# 03 — Art Direction

## Le mot-clé directeur

> **"A luxurious grimoire rendered as a premium mobile app."**

Imagine qu'un bibliothécaire de Prague au XVIIIe siècle avait conçu une app iOS. Ornementation baroque encrée d'or, typographie lettrée, noir profond, accents sang et or. Mais l'ergonomie, le rythme, la lisibilité sont ceux de 2026.

## Références à avoir en tête

- **Alphonse Mucha** — art nouveau, ornements filigranés, portraits élégants
- **Aubrey Beardsley** — gravures noir et blanc théâtrales, silhouettes
- **Edward Gorey** — illustrations gothiques semi-ironiques
- **Manuscrits enluminés médiévaux** — marges ornées, lettrines
- **Ex-libris XIXe** — gravures dorées sur fond noir
- **Interview with the Vampire (2022)** — dark romantic TV aesthetic
- **Dracula BBC / Nosferatu (2024)** — contemporain mais classique

**À éviter absolument :**
- Cartoon / kawaii / anime chibi
- Flat design / Material Design / iOS natif
- Neomorphism / glass-morphism
- Neon cyberpunk
- Retro pixel art (ça casse le register premium)

## Palette (strict)

```css
/* BASE */
--void:       #08050a   /* noir avec soupçon pourpre */
--deep:       #12090e   /* sombre tinted */
--paper:      #1a0f14   /* parchemin vieilli noir */
--ink:        #f3ead8   /* blanc os, jamais pur blanc */
--ink-dim:    #a89986
--ink-faint:  #5c4f42

/* ACCENTS */
--blood:      #a51423   /* rouge profond riche, numbers principaux */
--blood-dark: #6b0e18
--blood-glow: #ff3342   /* pour glow, crits, highlights */
--gold:       #c9a962   /* or antique oxydé, ornements */
--gold-dim:   #8a7444
--shadow:     #6b2d8f   /* pourpre mystique, méta-layer */
--moon:       #e8dfc8   /* lune froide, accent très rare */
```

### Règles de couleur

- **80% de l'écran en noir profond.** Toujours.
- **Gold** → ornements, frames, titre de rank actuel
- **Blood** → chiffres principaux, accents de vie/sang
- **Shadow (pourpre)** → ressources méta (Dread), rarement utilisé
- **Un seul accent dominant par écran** à un instant donné
- **Pas de rouge vif** (on utilise blood-dark ou blood, pas blood-glow sauf crits)

## Typographie

### Display ornementale — `UnifrakturCook`
- Uniquement pour le titre "VAMPIRE MAXXING" (2 lignes, en haut à gauche)
- Blood color, subtle text-shadow rouge
- Ne JAMAIS utiliser ailleurs

### Elegance — `Cormorant Garamond`
- Titres de sections, titre de rank actuel ("a Lord of Night"), flavor text
- Weights 400/500/600, italics pour emphases
- Letter-spacing : 0.05-0.15em

### Data — `JetBrains Mono`
- Tous les chiffres (blood counter, cost, rate, dread)
- UI meta (labels "YOU ARE", "DREAD", "BLOOD")
- Weights 300/400/500
- **Toujours `font-variant-numeric: tabular-nums`**
- Letter-spacing : 0.2-0.4em pour les caps

**Le contraste 3-way est essentiel** : ornemental gothique + elegant serif + modern mono. C'est l'identité. Ne pas simplifier.

## Ornementation

### Principe

**Aucun bord n'est nu.** Toute carte, cadre, bouton a une ornementation — coin flourishes, dividers centraux, filigree. Codé en **SVG inline**, pas en PNG.

### Composants ornementaux récurrents à coder

1. **Coin flourish** (`src/ui/ornaments/corner.ts`) — coin décoratif 8-12px, 4 variantes selon la position (TL, TR, BL, BR). Utilisé sur toutes les cartes et frames.

2. **Divider with centerpiece** (`src/ui/ornaments/divider.ts`) — ligne horizontale avec ornement central (❦, ◈, ♰, ✦). Fadé en dégradé vers les bords.

3. **Portrait frame** (`src/ui/ornaments/portrait-frame.ts`) — le BIG ONE. Cadre ornementé complet autour du portrait central. Référence : le mockup ChatGPT. SVG complexe avec coins baroques, bordures filigranées.

4. **Thrall frame** (`src/ui/ornaments/thrall-frame.ts`) — cercle ornementé qui encadre chaque illustration de thrall. Variante simplifiée du portrait frame.

5. **Button ornaments** (`src/ui/ornaments/button.ts`) — petits coins ornementaux pour les boutons BOOST et ASCEND.

Chaque ornement :
- Code en SVG inline (TS template literal)
- Couleur via `currentColor` ou CSS variable
- Scalable (viewBox proportionnel)
- Pas de fichier externe

### Références visuelles dans le mockup

Regarder `design/mockup.png` et noter :
- Le cadre du portrait a des **rosettes** aux 4 coins
- Le divider central a un ❦ (fleur gothique)
- Les cartes de thralls ont des **coins angulaires** en or
- Les boutons ont une double bordure avec coins
- Le footer invisible suggère une **ligne de château** stylisée

**Claude Code doit reproduire ces ornements en SVG, pas les copier depuis l'image.**

## Composants visuels clés

### 1. Portrait central (LE cœur de l'UI)
- Taille : ~70% de la largeur de l'écran
- Aspect ratio : 1:1 (carré)
- Image chargée depuis `assets/portraits/[form-id].png`
- **Encadré** par le portrait-frame ornementé (SVG)
- **Aura rouge douce** émanant (CSS box-shadow + filter)
- Au-dessus : label "— THE BLOODLINE —" en mono caps
- Au-dessous : titre italique "Lord of Night · Century IV"
- Animation : léger breathing effect (scale 1→1.02 sur 4s)
- **Lors d'un prestige avec changement de forme** : transition dramatique (fade to black, fade in nouveau portrait, titre qui change en scroll)

### 2. Blood counter
- Font : JetBrains Mono, 42-48px
- Color : `--blood` avec text-shadow rouge
- `font-variant-numeric: tabular-nums`
- Au-dessus : "— blood —" italique serif faint
- Au-dessous : "+342 / per second" en mono, "+342" en `--blood-glow`
- Sur tap : bump animation micro (scale 1→1.03→1 sur 150ms)

### 3. Thrall cards
- Structure grid : `48px (portrait rond) | 1fr (info) | auto (cost)`
- Fond : `linear-gradient(135deg, rgba(26,15,20,0.85), rgba(12,8,12,0.9))`
- Bordure : 1px `rgba(201,169,98,0.12)` (gold dim)
- Coins ornementaux en haut-gauche (via SVG)
- État affordable : bordure gold vif + shimmer animation
- État locked : opacity 0.3, filter saturate(0.25)

### 4. Boutons actions (BOOST + ASCEND)
- Deux colonnes égales en bas d'écran
- BOOST : bordure gold, texte gold
- ASCEND : bordure blood, texte blood-glow, pulse animation
- Double bordure ornementale (SVG borders)
- Sub-label italique serif

### 5. Header
- 3 colonnes : brand | identity | dread
- Brand "Vampire Maxxing" sur 2 lignes en UnifrakturCook
- Identity avec label mono + titre serif italique + rang en chiffres romains
- Dread en mono avec symbole ×

## Effets visuels (VFX)

### Particles de sang (tap)
- Burst 8 particules sur tap normal, 18 sur crit
- Normal : rouges (`--blood` et `--blood-glow`)
- Crit : dorées (`--gold`)
- Gravité positive (tombent)
- Fade sur 800ms-1.2s
- Shadow-blur 10px pour glow

### Embers ambient
- Particules qui montent lentement depuis le bas
- Rouge foncé (75%) et or (25%)
- ~30 particules max on-screen
- Très subtile, ajoute profondeur atmosphérique

### Fog animé
- 2 gradients radiaux très subtils qui dérivent
- Animation 30s ease-in-out infinite alternate
- Mix-blend-mode screen
- Teinte rouge/pourpre

### Grain texture
- Overlay plein écran via SVG turbulence filter
- Opacity 0.06
- Mix-blend-mode overlay
- Donne un feel "papier ancien"

### Drips de sang
- Depuis le portrait, 3 drips à intervalles désynchronisés
- Goutte qui tombe ~30px puis fade
- Animation 5s staggered

### Chauves-souris
- 1-2 silhouettes qui traversent l'écran rarement
- Très faibles (opacity 0.4)
- Icône Phosphor `ph-fill ph-bat`

### Ascension (prestige animation)
1. Screen flash rouge → noir (500ms)
2. Portrait actuel se dissout en particules rouges (800ms)
3. Nouveau portrait apparaît avec aura dorée (800ms)
4. Nouveau titre se révèle caractère par caractère (600ms)
5. Toast avec flavor text ("You have become something greater.")

## Sonore (placeholder MVP)

Audio désactivé par défaut. Option "AMBIENCE" dans settings qui active :
- Ambient drone via Tone.js (pad lent + vent léger)
- Tap : sine wave 220Hz (plus grave que Cosmic Forge, plus organique)
- Crit : triangle 440Hz avec décay long
- Achat thrall : cloche grave 150Hz
- Ascension : accord montant mineur sur 3s

Pas d'audio file. Tout généré. Voir `specs/AUDIO-ENGINE.md`.

## Ce qu'on évite absolument

- ❌ Icônes "Material Design" ou "Feather Icons" cutesy
- ❌ Border-radius > 4px (sauf cercles complets)
- ❌ Fond gris ou beige
- ❌ Gradients violet → rose générique (pas Spotify aesthetic)
- ❌ Animations bouncy / overshoot cartoon
- ❌ Polices sans-serif modernes
- ❌ Emoji dans l'UI (sauf dans achievements mémés textuels)
- ❌ Fluos saturés
- ❌ Assets décoratifs en PNG (tout ornement est SVG code)
- ❌ Drop shadows banals — on utilise des glows ou rien

## Référence absolue

Le fichier `design/mockup.png` est le **gold standard visuel**. Claude Code doit :
1. L'ouvrir et l'analyser à chaque début de session
2. Le référencer pour chaque décision de layout ou d'ornementation
3. Signaler si une spec contredit le mockup (la spec gagne, mais on discute)

Le but : que quelqu'un qui compare le jeu fini et le mockup ait du mal à les distinguer.
