# 05 — Monétisation

## Philosophie

**Non-hostile.** Pub récompensée uniquement. IAPs cosmétiques exclusivement. Pas de pay-to-progress.

Le joueur F2P a accès à 100% du jeu. Les payeurs soutiennent le projet et se démarquent esthétiquement.

## Règles

- **Zéro pub intrusive.** Pas d'interstitiel, pas de banner, pas de pop-up commercial.
- **Toutes les pubs sont récompensées** et déclenchées par le joueur.
- **IAPs cosmétiques uniquement au MVP.**
- **Pas de dark pattern** : pas de fausse urgence, pas de timer artificiel.
- **Pas de monétisation en première session** — on laisse le joueur découvrir le jeu intact.

## Sources de revenus au MVP

### 1. Pub récompensée (AdMob Rewarded)

Langage in-game : les pubs sont appelées **"rites"** ou **"offerings"**, pour rester dans le ton.

| Contexte                        | Bouton UI                 | Récompense                        |
|---------------------------------|---------------------------|-----------------------------------|
| Bouton × BOOST pub variant      | **"SUMMON THE NIGHT"**    | Boost 2× pendant 2 min, no cooldown |
| Retour après > 30 min           | **"EMBRACE THE DAWN"**    | Offline 100% eff + cap 6h au lieu de 50%/4h |
| Au moment d'Ascend              | **"INVOKE THE CURSE"**    | × 2 Dread sur cet Ascend          |
| Daily gift                      | **"OFFERING"**            | Blood bonus aligned sur le rate actuel |

Implémentation : `@capacitor-community/admob`, IDs de test en dev, vrais en prod.

### 2. IAP cosmétiques (Google Play Billing)

3 packs au MVP, tous à **2.99€** :

#### **Pack "NOSFERATU"** — *For the old soul*
- Palette : noir profond + blanc os + rouge carmin unique (expressionnisme allemand)
- Portraits variants : plus stylisés, angles durs, ombres dramatiques
- Thralls variants : silhouettes plus marquées
- Pour les 8 formes (8 portraits alternatifs)
- Sous-titre store : *"The original nightmare."*

#### **Pack "CRIMSON COURT"** — *For the aristocrat*
- Palette : rouge profond + or opulent + noir (baroque décadent)
- Portraits variants : plus ornés, dorures, pierreries
- Ornements UI : filigree plus chargés, couleur rouge-or
- Sous-titre store : *"Opulence. Decadence. Eternity."*

#### **Pack "VOID CULT"** — *For the cosmic horror*
- Palette : noir + violet profond + cyan glacier (horror cosmique)
- Portraits variants : plus eldritch, géométries occultes, tentacules
- Effets particules : pourpres au lieu de rouges
- Sous-titre store : *"Reality was never a promise."*

### 3. Founder Pack (9.99€, limité aux 90 premiers jours)
- Inclut les 3 skins ci-dessus
- Titre unique **"FIRST BLOOD"** affiché sous le titre de forme
- Medaillon doré permanent à côté du nom
- Sous-titre : *"Among the first to awaken."*

## Placements UI

### Store access
- Icône **❦** (fleur gothique or) en haut à droite du header
- Ouvre un modal "APOTHECARY" (nom in-game du store)
- Layout : 3 cartes de skins en grid, chacune avec preview animé du portrait + prix
- Bouton RESTORE PURCHASES en bas

### Rewarded ad buttons
- Toujours un label clair avec icône ▶ ou ◆
- Jamais de popup auto-play
- Premier placement (offline claim) : **après la 2e session**, jamais en première
- Fallback si ad fail : toast discret "THE RITE FAILED"

## Projections

**Hypothèse : 1000 DAU stables après 3 mois.**

| Source           | ARPU estimé | Revenu mensuel estimé |
|------------------|-------------|------------------------|
| Pub récompensée  | 0.07€/DAU   | 2100€                  |
| IAP              | 0.05€/DAU   | 1500€                  |
| **Total**        | **0.12€/DAU**| **~3600€**            |

Le thème viral devrait permettre un CTR plus élevé sur le Play Store que Cosmic Forge, et le contenu TikTok organique devrait réduire la dépendance au UA.

## Ce qu'on NE fait PAS

- ❌ IAP de progression (pas de "pack 1000 Dread")
- ❌ Pub interstitielle
- ❌ Pub au lancement de l'app
- ❌ Notifications push commerciales
- ❌ Limite quotidienne F2P
- ❌ Currency premium (gems) en plus de Dread
- ❌ Loot boxes / gacha
- ❌ Abonnement au MVP (v1.2+ avec "Bloodline+" à 2.99€/mois : cosmétiques mensuels + cloud save + pas de pub)

## Conformité

- **Google Play** : déclarer ads + IAPs dans Play Console
- **GDPR** : UMP consent flow au premier lancement en EU
- **RGPD enfants** : "not made for kids" (thème vampire/blood = pas family-friendly de toute façon). Rating PEGI 12+ visé.
- **Privacy policy** : template dans `specs/PRIVACY-TEMPLATE.md`, hébergée sur domaine dédié
- **Content rating** : déclarer "moderate violence" (fangs, blood motifs), "no drugs", "no nudity"

## Roadmap de monétisation post-MVP

- **v1.1** : 2 skins saisonniers limités (Halloween "All Souls Court", Saint-Valentin "Crimson Romance")
- **v1.2** : Bloodline+ abonnement (2.99€/mois)
- **v1.3** : Event-based monétisation (lune rouge, événements narratifs)
- **v2.0** : iOS + éventuel pass saisonnier narratif (30 jours d'histoire)
