# SPEC — Ornaments System

> Tous les ornements décoratifs (frames, dividers, coin flourishes) sont des SVG inline codés. Aucun PNG ornemental.

## Fichiers à créer

Structure `src/ui/ornaments/` :

```
src/ui/ornaments/
├── index.ts                 ← exports publics
├── corner.ts                ← coin flourishes (4 variantes: tl, tr, bl, br)
├── divider.ts               ← ligne avec centerpiece
├── portrait-frame.ts        ← frame complet autour du portrait (référence : mockup)
├── thrall-frame.ts          ← cercle ornementé pour les thralls
├── button-border.ts         ← bordures boutons avec petits coins
└── moon.ts                  ← lune décorative coin haut-droit
```

## Principes communs

- Toutes les fonctions retournent un `SVGElement` prêt à insérer
- Toutes utilisent `currentColor` pour le stroke/fill → thémable via CSS `color`
- `viewBox` proportionnel à une taille passée en paramètre
- Pas de style CSS inline en dur — tout via classes et variables

## Corner flourish

```ts
// src/ui/ornaments/corner.ts
export type CornerPosition = 'tl' | 'tr' | 'bl' | 'br';

export function createCorner(position: CornerPosition, size: number = 10): SVGElement {
  const ns = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(ns, 'svg');
  svg.setAttribute('viewBox', `0 0 ${size} ${size}`);
  svg.setAttribute('width', `${size}`);
  svg.setAttribute('height', `${size}`);
  svg.setAttribute('class', `ornament-corner corner-${position}`);
  
  // Le path du coin - 2 traits perpendiculaires + petit motif floral
  // Designed pour être lisible à 8-12px
  const path = document.createElementNS(ns, 'path');
  path.setAttribute('d', cornerPath(position, size));
  path.setAttribute('stroke', 'currentColor');
  path.setAttribute('stroke-width', '1');
  path.setAttribute('fill', 'none');
  
  svg.appendChild(path);
  return svg;
}

function cornerPath(position: CornerPosition, s: number): string {
  // Base TL corner : descends du top-left, petit curlicue au centre
  const base = `M 0 ${s/2} L 0 0 L ${s/2} 0 M ${s/4} 0 Q ${s/3} ${s/4}, ${s/2} ${s/4}`;
  // Rotate/flip pour les autres positions
  // ... implémenter les 4 variantes
}
```

Usage dans les composants :

```ts
// Dans une thrall-card
const card = document.createElement('div');
card.className = 'gen';
card.appendChild(createCorner('tl'));  // Coin haut-gauche
// ...
```

CSS :
```css
.ornament-corner {
  position: absolute;
  color: var(--gold-dim);
  opacity: 0.5;
}
.corner-tl { top: 0; left: 0; }
.corner-tr { top: 0; right: 0; transform: rotate(90deg); }
.corner-bl { bottom: 0; left: 0; transform: rotate(-90deg); }
.corner-br { bottom: 0; right: 0; transform: rotate(180deg); }
```

## Divider

```ts
// src/ui/ornaments/divider.ts
export function createDivider(centerpiece: '❦' | '◈' | '♰' | '✦' = '❦'): HTMLElement {
  const div = document.createElement('div');
  div.className = 'ornament-divider';
  
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('viewBox', '0 0 200 20');
  svg.setAttribute('class', 'divider-svg');
  svg.setAttribute('preserveAspectRatio', 'none');
  
  // Left fading line
  const leftLine = document.createElementNS(/* ns */, 'line');
  // ... trait qui fade de 0 opacité à 0.4 en or
  
  // Right fading line  
  const rightLine = /* ... symétrique */;
  
  // Small curl ornaments on each side of the center
  // ...
  
  div.appendChild(svg);
  
  const center = document.createElement('span');
  center.className = 'divider-centerpiece';
  center.textContent = centerpiece;
  div.appendChild(center);
  
  return div;
}
```

CSS :
```css
.ornament-divider {
  position: relative;
  height: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
}
.divider-svg {
  position: absolute;
  inset: 0;
  color: var(--gold-dim);
}
.divider-centerpiece {
  position: relative;
  color: var(--gold);
  font-size: 14px;
  padding: 0 12px;
  background: var(--void);
}
```

## Portrait frame (LE gros morceau)

C'est le SVG le plus complexe. Reproduit le cadre qu'on voit dans le mockup.

Éléments :
1. **Rectangle double** (outer + inner borders avec espace)
2. **4 rosettes ornementales** aux coins (petits motifs floraux détaillés)
3. **Filigree patterns** le long des bords (courbes art nouveau répétées)
4. **Optional : ornement central** en haut et en bas (petit ornement qui dépasse du cadre)

Taille typique : 400×400 pour un portrait de 350×350 à l'intérieur.

Claude Code doit **analyser le mockup (`design/mockup.png`)** pour reproduire fidèlement. La richesse du cadre est essentielle au feel premium.

Structure suggérée :

```ts
// src/ui/ornaments/portrait-frame.ts
export function createPortraitFrame(size: number = 400): SVGElement {
  const svg = /* ... créer SVG avec viewBox 0 0 size size */;
  
  // Layer 1: Double rectangle
  svg.appendChild(createOuterRect(size));
  svg.appendChild(createInnerRect(size));
  
  // Layer 2: Corner rosettes
  svg.appendChild(createRosette('tl', size));
  svg.appendChild(createRosette('tr', size));
  svg.appendChild(createRosette('bl', size));
  svg.appendChild(createRosette('br', size));
  
  // Layer 3: Edge filigrees
  svg.appendChild(createEdgeFiligree('top', size));
  svg.appendChild(createEdgeFiligree('right', size));
  svg.appendChild(createEdgeFiligree('bottom', size));
  svg.appendChild(createEdgeFiligree('left', size));
  
  // Layer 4: Top and bottom center ornaments (optional dépassement)
  svg.appendChild(createCenterOrnament('top', size));
  svg.appendChild(createCenterOrnament('bottom', size));
  
  return svg;
}

function createRosette(pos: CornerPosition, size: number): SVGElement {
  // Un motif ~25×25px au coin
  // Style : 4 pétales avec filigree, point central
  // Référence visuelle : mockup
  // ...
}
```

Le détail précis des paths SVG est trop long pour ce doc — Claude Code étudie le mockup et implémente.

## Thrall frame

Similaire au portrait frame mais :
- Circulaire (pas carré)
- Plus simple (moins d'ornements parce que plus petit, ~48px)
- Juste un cercle double + 4 petits accents aux cardinaux

```ts
export function createThrallFrame(size: number = 48): SVGElement {
  // Cercle double avec 4 petits points dorés aux NSEW
  // ...
}
```

## Button border

Bordure ornementée pour les boutons BOOST / ASCEND.

- Rectangle avec coins légèrement décoratifs (pas de rosettes complètes, juste des petits coins angulaires)
- Double bordure (extérieure + intérieure avec gap de 2px)
- Pour ASCEND : aura rouge en + (box-shadow CSS, pas SVG)

## Moon decoration

Phosphor icon suffit (`ph-duotone ph-moon`) positionnée en haut-droite. Pas besoin de SVG custom.

## Tests visuels

Pas de test unitaire automatique (difficile pour SVG). Mais Claude Code doit :
1. Screenshot chaque ornement isolé → comparer visuellement
2. Intégrer dans l'UI → vérifier que le rendu matche le mockup
3. Tester à plusieurs tailles (responsive)

## Performance

- Les SVG sont légers (quelques ko inline)
- Ils ne sont créés **qu'une fois** par composant (pas recréés à chaque tick)
- Pas de filter SVG lourd (pas de Gaussian blur en SVG — on fait ça en CSS)
